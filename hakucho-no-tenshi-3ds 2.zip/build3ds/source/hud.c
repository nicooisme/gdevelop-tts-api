#include "game.h"
#include <stdio.h>
#include <math.h>

C2D_TextBuf g_textBuf;

#define PINK_BG    C2D_Color32(255, 173, 211, 255)
#define PINK_DOT   C2D_Color32(255, 110, 170, 255)
#define PINK_DOT2  C2D_Color32(255, 200, 225, 255)

static void draw_text_centered(const char *str, float cx, float y, float scale, u32 color)
{
    C2D_Text text;
    C2D_TextParse(&text, g_textBuf, str);
    C2D_TextOptimize(&text);
    float w, h;
    C2D_TextGetDimensions(&text, scale, scale, &w, &h);
    C2D_DrawText(&text, C2D_WithColor, cx - w * 0.5f, y, 0.5f, scale, scale, color);
}

/* simple pink polka-dot backdrop used on menus / HUD chrome (not on the
   island itself, which keeps its snow/grass/stone/water look) */
static void draw_polka_bg(float w, float h)
{
    C2D_DrawRectSolid(0, 0, 0.0f, w, h, PINK_BG);
    float spacing = 26.0f;
    float dot = 8.0f;
    int row = 0;
    for (float y = -spacing; y < h + spacing; y += spacing) {
        float offset = (row % 2 == 0) ? 0.0f : spacing * 0.5f;
        for (float x = -spacing + offset; x < w + spacing; x += spacing) {
            C2D_DrawRectSolid(x, y, 0.05f, dot, dot, PINK_DOT);
            C2D_DrawRectSolid(x + dot * 0.25f, y + dot * 0.25f, 0.06f, dot * 0.5f, dot * 0.5f, PINK_DOT2);
        }
        row++;
    }
}

/* ---------------- camera helpers ---------------- */
static float s_camX = 0.0f, s_camY = 0.0f;

static void update_camera(Entity *player)
{
    float viewW = TOP_W / ZOOM;
    float viewH = TOP_H / ZOOM;
    s_camX = player->x - viewW * 0.5f;
    s_camY = player->y - viewH * 0.5f;
    if (s_camX < 0) s_camX = 0;
    if (s_camY < 0) s_camY = 0;
    if (s_camX > MAP_W - viewW) s_camX = MAP_W - viewW;
    if (s_camY > MAP_H - viewH) s_camY = MAP_H - viewH;
}

static inline float scrX(float worldX) { return (worldX - s_camX) * ZOOM; }
static inline float scrY(float worldY) { return (worldY - s_camY) * ZOOM; }

static void draw_img_world(C2D_Image img, float wx, float wy, float depth)
{
    C2D_DrawImageAt(img, scrX(wx), scrY(wy), depth, NULL, ZOOM, ZOOM);
}

static void draw_rect_world(float wx, float wy, float depth, float w, float h, u32 color)
{
    C2D_DrawRectSolid(scrX(wx), scrY(wy), depth, w * ZOOM, h * ZOOM, color);
}

/* ---------------- TOP SCREEN : the island + characters ---------------- */
void render_top(Entity all[], int count)
{
    C2D_TextBufClear(g_textBuf);

    Entity *player = &all[0];
    update_camera(player);

    float viewW = TOP_W / ZOOM, viewH = TOP_H / ZOOM;

    int tx0 = (int)(s_camX / TILE) - 1;
    int ty0 = (int)(s_camY / TILE) - 1;
    int tx1 = (int)((s_camX + viewW) / TILE) + 1;
    int ty1 = (int)((s_camY + viewH) / TILE) + 1;
    if (tx0 < 0) tx0 = 0; if (ty0 < 0) ty0 = 0;
    if (tx1 > COLS) tx1 = COLS; if (ty1 > ROWS) ty1 = ROWS;

    for (int y = ty0; y < ty1; y++) {
        for (int x = tx0; x < tx1; x++) {
            draw_img_world(g_tileImg[g_map[y][x]], x * TILE, y * TILE, 0.0f);
        }
    }

    int ix0 = (int)(s_camX / INK_CELL) - 1;
    int iy0 = (int)(s_camY / INK_CELL) - 1;
    int ix1 = (int)((s_camX + viewW) / INK_CELL) + 1;
    int iy1 = (int)((s_camY + viewH) / INK_CELL) + 1;
    if (ix0 < 0) ix0 = 0; if (iy0 < 0) iy0 = 0;
    if (ix1 > INK_COLS) ix1 = INK_COLS; if (iy1 > INK_ROWS) iy1 = INK_ROWS;

    for (int iy = iy0; iy < iy1; iy++) {
        for (int ix = ix0; ix < ix1; ix++) {
            Team t = g_ink[iy][ix];
            if (t == TEAM_NONE) continue;
            u32 color = (t == TEAM_ORANGE)
                ? C2D_Color32(255, 122, 24, 140)
                : C2D_Color32(43, 140, 255, 140);
            draw_rect_world(ix * INK_CELL, iy * INK_CELL, 0.3f, INK_CELL, INK_CELL, color);
        }
    }

    for (int i = 0; i < count; i++) {
        Entity *e = &all[i];
        if (e->dead) continue;

        u32 ringColor = (e->team == TEAM_ORANGE)
            ? C2D_Color32(255, 122, 24, 110)
            : C2D_Color32(43, 140, 255, 110);
        draw_rect_world(e->x - 12.0f, e->y + 5.0f, 0.25f, 24.0f, 6.0f, ringColor);

        if (e->invuln > 0.0f && ((int)(e->invuln * 10.0f) % 2 == 0)) continue;

        C2D_Image img = e->moving
            ? g_charWalk[e->skin][e->animFrame]
            : g_charIdle[e->skin][e->animFrame % 2];

        draw_img_world(img, e->x - 14.0f, e->y - 26.0f, 0.2f);

        if (e->isPlayer && e->hair > 0 && e->hair <= HAIR_COUNT) {
            draw_img_world(g_hairImg[e->hair - 1], e->x - 14.0f, e->y - 26.0f, 0.15f);
        }
    }
}

/* ---------------- BOTTOM SCREEN : 5 hearts (bem maiores) + timer + score ---------------- */
void render_bottom(Entity *player, float timeLeft, int covO, int covB)
{
    draw_polka_bg(BOT_W, BOT_H);

    int full = (int)ceilf(player->hp);
    if (full < 0) full = 0;
    if (full > 5) full = 5;

    float heartSize = 56.0f;
    float gap = 6.0f;
    float totalW = 5 * heartSize + 4 * gap;
    float startX = (BOT_W - totalW) * 0.5f;
    float heartY = 28.0f;

    for (int i = 0; i < 5; i++) {
        C2D_Image img = (i < full) ? g_hpFull : g_hpEmpty;
        float scale = heartSize / 96.0f;
        C2D_DrawImageAt(img, startX + i * (heartSize + gap), heartY, 0.4f, NULL, scale, scale);
    }

    int t = (int)(timeLeft > 0 ? timeLeft : 0);
    int mm = t / 60, ss = t % 60;
    char buf[16];
    snprintf(buf, sizeof(buf), "%d:%02d", mm, ss);
    draw_text_centered(buf, BOT_W * 0.5f, 100.0f, 1.4f, C2D_Color32(60, 20, 45, 255));

    char scoreBuf[48];
    snprintf(scoreBuf, sizeof(scoreBuf), "LARANJA %d%%   x   AZUL %d%%", covO, covB);
    draw_text_centered(scoreBuf, BOT_W * 0.5f, 150.0f, 0.75f, C2D_Color32(80, 30, 55, 255));

    draw_text_centered("Circle Pad: mover  -  pinta sozinho ao andar",
                        BOT_W * 0.5f, 195.0f, 0.5f, C2D_Color32(120, 50, 80, 255));
}

/* ---------------- TITLE / END overlays (drawn on TOP screen) ---------------- */
static const char *hair_label(int h)
{
    switch (h) {
        case 0: return "Nenhum";
        case 1: return "Estilo 1";
        case 2: return "Estilo 2";
        case 3: return "Estilo 3";
        case 4: return "Estilo 4";
        case 5: return "Estilo 5";
        case 6: return "Estilo 6";
        default: return "?";
    }
}

void render_title(int hairChoice)
{
    draw_polka_bg(TOP_W, TOP_H);

    draw_text_centered("HAKUCHOU NO TENSHI", TOP_W * 0.5f, 36.0f, 1.3f, C2D_Color32(255, 255, 255, 255));
    draw_text_centered("guerra de tinta na ilha nevada", TOP_W * 0.5f, 70.0f, 0.7f, C2D_Color32(90, 30, 55, 255));

    float px = TOP_W * 0.5f - 14.0f * 2.0f, py = 95.0f;
    C2D_DrawImageAt(g_charIdle[0][0], px, py, 0.2f, NULL, 2.0f, 2.0f);
    if (hairChoice > 0) {
        C2D_DrawImageAt(g_hairImg[hairChoice - 1], px, py, 0.15f, NULL, 2.0f, 2.0f);
    }

    char hairBuf[48];
    snprintf(hairBuf, sizeof(hairBuf), "< Cabelo: %s >", hair_label(hairChoice));
    draw_text_centered(hairBuf, TOP_W * 0.5f, 175.0f, 0.85f, C2D_Color32(60, 20, 45, 255));
    draw_text_centered("D-Pad esquerda/direita para trocar", TOP_W * 0.5f, 200.0f, 0.55f, C2D_Color32(110, 45, 75, 255));

    draw_text_centered("START para comecar", TOP_W * 0.5f, 220.0f, 0.9f, C2D_Color32(200, 40, 110, 255));
}

void render_end(int covO, int covB)
{
    draw_polka_bg(TOP_W, TOP_H);

    const char *result;
    u32 color;
    if (covO > covB)      { result = "VOCE VENCEU!"; color = C2D_Color32(220, 30, 100, 255); }
    else if (covB > covO) { result = "VOCE PERDEU";  color = C2D_Color32(70, 40, 90, 255); }
    else                   { result = "EMPATE!";       color = C2D_Color32(255, 255, 255, 255); }

    draw_text_centered(result, TOP_W * 0.5f, 80.0f, 1.3f, color);

    char scoreBuf[48];
    snprintf(scoreBuf, sizeof(scoreBuf), "Laranja %d%%  x  Azul %d%%", covO, covB);
    draw_text_centered(scoreBuf, TOP_W * 0.5f, 120.0f, 0.9f, C2D_Color32(60, 20, 45, 255));

    draw_text_centered("START para jogar de novo", TOP_W * 0.5f, 170.0f, 0.8f, C2D_Color32(110, 45, 75, 255));
}
