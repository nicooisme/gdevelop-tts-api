#include "game.h"
#include <math.h>
#include <stdlib.h>

TileType g_map[ROWS][COLS];
Team     g_ink[INK_ROWS][INK_COLS];

static int s_landMaskInk[INK_ROWS][INK_COLS]; /* 1 if this ink cell sits over land */
static int s_landSamples = 1;

static float frand01(void) { return (rand() % 1000) / 1000.0f; }

void map_generate(void)
{
    float cx = COLS / 2.0f - 0.3f;
    float cy = ROWS / 2.0f;
    float s1 = frand01() * 6.2831f;
    float s2 = frand01() * 6.2831f;

    for (int ty = 0; ty < ROWS; ty++) {
        for (int tx = 0; tx < COLS; tx++) {
            float dx = (tx - cx) / (COLS * 0.5f);
            float dy = (ty - cy) / (ROWS * 0.5f);
            float ang = atan2f(dy, dx);
            float dyy = dy * 1.05f;
            float d = sqrtf(dx * dx + dyy * dyy);
            float edge = 0.84f + 0.17f * sinf(ang * 3 + s1) + 0.10f * sinf(ang * 5 + s2);

            TileType t = TILE_WATER;
            if (d < edge) {
                t = TILE_GRASS;
                int cxi = COLS / 2, cyi = ROWS / 2;
                if (abs(tx - cxi) <= 1 || abs(ty - cyi) <= 1) t = TILE_STONE;
                if (ty < (int)(ROWS * 0.34f)) t = TILE_SNOW;
            }
            g_map[ty][tx] = t;
        }
    }

    /* land mask for the finer ink grid + clear ink ownership */
    s_landSamples = 0;
    for (int iy = 0; iy < INK_ROWS; iy++) {
        for (int ix = 0; ix < INK_COLS; ix++) {
            g_ink[iy][ix] = TEAM_NONE;
            float px = ix * INK_CELL + INK_CELL * 0.5f;
            float py = iy * INK_CELL + INK_CELL * 0.5f;
            int tx = (int)(px / TILE), tyy = (int)(py / TILE);
            int land = (tx >= 0 && tyy >= 0 && tx < COLS && tyy < ROWS &&
                        g_map[tyy][tx] != TILE_WATER);
            s_landMaskInk[iy][ix] = land;
            if (land) s_landSamples++;
        }
    }
    if (s_landSamples < 1) s_landSamples = 1;
}

TileType map_tile_at_px(float x, float y)
{
    int tx = (int)(x / TILE), ty = (int)(y / TILE);
    if (tx < 0 || ty < 0 || tx >= COLS || ty >= ROWS) return TILE_WATER;
    return g_map[ty][tx];
}

int map_is_land_px(float x, float y)
{
    return map_tile_at_px(x, y) != TILE_WATER;
}

static void ink_cell_xy(float x, float y, int *ix, int *iy)
{
    *ix = (int)(x / INK_CELL);
    *iy = (int)(y / INK_CELL);
}

void ink_paint(float x, float y, float radius, Team team)
{
    int cx, cy;
    ink_cell_xy(x, y, &cx, &cy);
    int r = (int)(radius / INK_CELL) + 1;

    for (int iy = cy - r; iy <= cy + r; iy++) {
        for (int ix = cx - r; ix <= cx + r; ix++) {
            if (ix < 0 || iy < 0 || ix >= INK_COLS || iy >= INK_ROWS) continue;
            float ccx = ix * INK_CELL + INK_CELL * 0.5f;
            float ccy = iy * INK_CELL + INK_CELL * 0.5f;
            float dx = ccx - x, dy = ccy - y;
            if (dx * dx + dy * dy <= radius * radius) {
                if (s_landMaskInk[iy][ix]) g_ink[iy][ix] = team;
            }
        }
    }
}

Team ink_owner_at_px(float x, float y)
{
    int ix, iy;
    ink_cell_xy(x, y, &ix, &iy);
    if (ix < 0 || iy < 0 || ix >= INK_COLS || iy >= INK_ROWS) return TEAM_NONE;
    return g_ink[iy][ix];
}

void ink_coverage(int *outO, int *outB)
{
    int o = 0, b = 0;
    for (int iy = 0; iy < INK_ROWS; iy++) {
        for (int ix = 0; ix < INK_COLS; ix++) {
            if (!s_landMaskInk[iy][ix]) continue;
            if (g_ink[iy][ix] == TEAM_ORANGE) o++;
            else if (g_ink[iy][ix] == TEAM_BLUE) b++;
        }
    }
    *outO = (int)(o * 100.0f / s_landSamples);
    *outB = (int)(b * 100.0f / s_landSamples);
}
